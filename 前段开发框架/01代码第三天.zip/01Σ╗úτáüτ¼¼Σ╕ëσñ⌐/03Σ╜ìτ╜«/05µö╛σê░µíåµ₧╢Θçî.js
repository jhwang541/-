/**
 * Created by xdyuan on 16/8/26.
 */
/**
 * Created by xdyuan on 16/8/25.
 */
/**
 * Created by xdyuan on 16/8/23.
 */


var $$ = {


    //去除左边空格
    ltrim:function(str){
        return str.replace(/(^\s*)/g,'');
    },
    //去除右边空格
    rtrim:function(str){
        return str.replace(/(\s*$)/g,'');
    },
    //去除空格
    trim:function(str){
        return str.replace(/(^\s*)|(\s*$)/g, '');
    },
    //ajax - 前面我们学习的
    myAjax:function(URL,fn){
        var xhr = createXHR();	//返回了一个对象，这个对象IE6兼容。
        xhr.onreadystatechange = function(){
            if(xhr.readyState === 4){
                if(xhr.status >= 200 && xhr.status < 300 || xhr.status == 304){
                    fn(xhr.responseText);
                }else{
                    alert("错误的文件！");
                }
            }
        };
        xhr.open("get",URL,true);
        xhr.send();

        //闭包形式，因为这个函数只服务于ajax函数，所以放在里面
        function createXHR() {
            //本函数来自于《JavaScript高级程序设计 第3版》第21章
            if (typeof XMLHttpRequest != "undefined") {
                return new XMLHttpRequest();
            } else if (typeof ActiveXObject != "undefined") {
                if (typeof arguments.callee.activeXString != "string") {
                    var versions = ["MSXML2.XMLHttp.6.0", "MSXML2.XMLHttp.3.0",
                            "MSXML2.XMLHttp"
                        ],
                        i, len;

                    for (i = 0, len = versions.length; i < len; i++) {
                        try {
                            new ActiveXObject(versions[i]);
                            arguments.callee.activeXString = versions[i];
                            break;
                        } catch (ex) {
                            //skip
                        }
                    }
                }

                return new ActiveXObject(arguments.callee.activeXString);
            } else {
                throw new Error("No XHR object available.");
            }
        }
    },
    //tab
    tab:function(id) {
        //如何获取某个父元素下面的子元素
        var box = document.getElementById(id);
        var spans = box.getElementsByTagName('span');
        var lis = box.getElementsByTagName('li');


        //两步走
        //第一步: 先把上半部分实现
        //群体绑定事件  -- 对所有的span绑定事件
        //群体绑定事件
        for(var i=0;i<spans.length;i++) {
            //相亲法则  -- 给男一号一个代号  --  怎么给 -- 自定义属性
            spans[i].index=i;
            spans[i].onmouseover = function() {
                //排他思想 --  将所有的span置为默认状态  --- 然后再将当前鼠标移上的span置为class -- select
                for(var i=0;i<spans.length;i++) {
                    spans[i].className='';
                    lis[i].className='';
                }
                this.className='select';
                lis[this.index].className='select';
            }
        }

    },
    //简单的数据绑定formateString
    formateString:function(str, data){
        return str.replace(/@\((\w+)\)/g, function(match, key){
            return typeof data[key] === "undefined" ? '' : data[key]});
    },
    //给一个对象扩充功能
    extendMany:function() {
        var key,i = 0,len = arguments.length,target = null,copy;
        if(len === 0){
            return;
        }else if(len === 1){
            target = this;
        }else{
            i++;
            target = arguments[0];
        }
        for(; i < len; i++){
            for(key in arguments[i]){
                copy = arguments[i][key];
                target[key] = copy;
            }
        }
        return target;
    },
    extend:function(tar,source) {
        //遍历对象
        for(var i in source){
            tar[i] = source[i];
        }
        return tar;
    },
    //随机数
    random: function (begin, end) {
        return Math.floor(Math.random() * (end - begin)) + begin;
    },
    //数据类型检测
    isNumber:function (val){
        return typeof val === 'number' && isFinite(val)
    },
    isBoolean:function (val) {
        return typeof val ==="boolean";
    },
    isString:function (val) {
        return typeof val === "string";
    },
    isUndefined:function (val) {
        return typeof val === "undefined";
    },
    isObj:function (str){
        if(str === null || typeof str === 'undefined'){
            return false;
        }
        return typeof str === 'object';
    },
    isNull:function (val){
        return  val === null;
    },
    isArray:function (arr) {
        if(arr === null || typeof arr === 'undefined'){
            return false;
        }
        return arr.constructor === Array;
    }

};


/*部分事件*/
$$.extend($$,{
    /*绑定事件*/
    on: function (id, type, fn) {
        //var dom = document.getElementById(id);
        var dom = $$.isString(id)?document.getElementById(id):id;
        //如果支持
        //W3C版本 --火狐 谷歌 等大多数浏览器
        //如果你想检测对象是否支持某个属性，方法，可以通过这种方式
        if(dom.addEventListener ) {
            dom.addEventListener(type, fn, false);
        }else if(dom.attachEvent){
            //如果支持 --IE
            dom.attachEvent('on' + type, fn);
        }
    },
    /*解除事件*/
    un:function(id, type, fn) {
        //var dom = document.getElementById(id);
        var dom = $$.isString(id)?document.getElementById(id):id;
        if(dom.removeEventListener){
            dom.removeEventListener(type, fn);
        }else if(dom.detachEvent){
            dom.detachEvent(type, fn);
        }

    },
    /*点击*/
    click : function(id,fn){
        this.on(id,'click',fn);
    },
    /*鼠标移上*/
    mouseover:function(id,fn){
        this.on(id,'mouseover',fn);
    },
    /*鼠标离开*/
    mouseout:function(id,fn){
        this.on(id,'mouseout',fn);
    },
    /*悬浮*/
    hover : function(id,fnOver,fnOut){
        //移上去就是一个状态
        if(fnOver){
            this.on(id,"mouseover",fnOver);
        }
        //移出来回到原来的状态
        if(fnOut){
            this.on(id,"mouseout",fnOut);
        }
    },
    //获取事件对象
    getEvent:function(e) {
        /* if (e){
         return e;
         }else {
         /!*这是ie获取事件对象的方式*!/
         return window.event;
         }*/
        //可以简单写成下面这一句
        return e ? e : window.event;
    },
    //获取目标对象
    getTarget:function(e) {
        var event = $$.getEvent(e);
        /*event.srcElementz合适IE的方式*/
        /*下面这个也叫作短路表达式*/
        return event.target || event.srcElement;

    },
    //阻止冒泡
    stopPropagation:function (e) {
        var event = $$.getEvent(e);
        if (event.stopPropagation){
            event.stopPropagation();
        }else {
            //早期IE阻止冒泡的方式
            event.cancelBubble = true;
        }
    }
});
/*这是委托的框架*/
$$.extend($$, {
    /**
     @para parentId 包裹容器的id
     @para selector 容器内元素的选择器，支持id和className
     @para fn 元素上要执行的函数
     @para pid父元素的id
     */
    delegate :function (pid, eventType, selector, fn) {
        //参数处理
        var parent = $$.$id(pid);
        function handle(e){
            var target = $$.getTarget(e);
            console.log(target.nodeName);
            /*nodeName:如果节点是元素节点，则 nodeName 属性返回标签名。
             如果节点是属性节点，则 nodeName 属性返回属性的名称。*/
            /*target.nodeName.toLowerCase()=== selector 节点名是否是一个标签选择器*/
            if(target.nodeName.toLowerCase()=== selector || target.id === selector || target.className.indexOf(selector) != -1){
                // 在事件冒泡的时候，会以此遍历每个子孙后代，如果找到对应的元素，则执行如下函数
                // 为什么使用call，因为call可以改变this指向
                // 大家还记得，函数中的this默认指向window，而我们希望指向当前dom元素本身
                fn.call(target);
            }
        }
        //当我们给父亲元素绑定一个事件，他的执行顺序：先捕获到目标元素，然后事件再冒泡
        //这里是是给元素对象绑定一个事件
        parent[eventType]=handle;
    }
});

//这是class封装
$$.extend($$, {
    $class: function(className, ctx) {
        //首先应该判断ctx是id字符串还是dom
        if ($$.isString(ctx)){
            //如果是字符串,曾变成dom对象
            ctx = document.getElementById(ctx);
        } else if(!ctx){
            //如果ctx不存在,没填写,
            ctx = document;
        }

        //下面的话ctx就是dom对象了

        //其次判断是否支持getElementsByClassName,支持的话那就直接使用
        //判断是否支持不需要加()
        if (ctx.getElementsByClassName){
            return ctx.getElementsByClassName(className);
        }else {
            //不支持的话就得自己遍历筛选了
            /*获取所有的元素*/
            var elements = ctx.getElementsByTagName("*");
            /*过滤筛选*/
            var arr = [];
            for(var i=0,len=elements.length; i<len; i++){
                if (elements[i].className == className){
                    arr.push(elements[i]);
                }
            }
            return arr;
        }

    }

});


$$.extend($$, {
    $id:function (str){
        return document.getElementById(str);
    },
    /*$tag:function(tag){
     return document.getElementsByTagName(tag);
     },*/
    $tag:function (tag, ctx) {
        //有时候ctx传进来不是一id字符串,而是一个dom对象怎么办?
        if ($$.isString(ctx)){
            ctx = $$.$id(ctx);
        }
        //如果ctx传进来了,并且存在
        if (ctx){
            return ctx.getElementsByTagName(tag);
        }else {
            return document.getElementsByTagName(tag);
        }
    },

    $class: function(className, ctx) {
        //首先应该判断ctx是id字符串还是dom
        if ($$.isString(ctx)){
            //如果是字符串,曾变成dom对象
            ctx = document.getElementById(ctx);
        } else if(!ctx){
            //如果ctx不存在,没填写,
            ctx = document;
        }

        //下面的话ctx就是dom对象了

        //其次判断是否支持getElementsByClassName,支持的话那就直接使用
        //判断是否支持不需要加()
        if (ctx.getElementsByClassName){
            return ctx.getElementsByClassName(className);
        }else {
            //不支持的话就得自己遍历筛选了
            /*获取所有的元素*/
            var elements = ctx.getElementsByTagName("*");
            /*过滤筛选*/
            var arr = [];
            for(var i=0,len=elements.length; i<len; i++){
                if (elements[i].className == className){
                    arr.push(elements[i]);
                }
            }
            return arr;
        }



    },
    //多组选择器
    $duozu: function (content) {
        //总体思路： 个个击破
        //找到个个 ---放在数组里面 ---遍历--个个击破
        //三种情况
        var arr=[];
        var result=[];
        var list=[];
        arr = content.split(',');
        console.log("arr:"+ arr);

        for(var i=0,len=arr.length;i<len;i++) {

            // #id  .class  h3
            var item = arr[i];//拿到整个
            //但是这样子拿到的item如果前后有空格的话就会出错了,需要去除前后的空格
            item = $$.trim(item);//去除前后的空格
            var first= item.charAt(0);//拿到第一个字符
            var index= item.indexOf(first);//拿到第一个字符的
            var name = item.slice(index+1);

            if(first =='.') {
                //各个击破-- class
                list = $$.$class(name);

            }else if(first =='#') {
                //各个击破 -- id
                list = [$$.$id(name)];

            }else{
                //各个击破 -- 标签
                list = $$.$tag(item);

            }
            pushArray(list);
        }
        //把解析出来的放入一个数组
        function pushArray(doms){
            for(var i= 0,len=doms.length;i<len;i++){
                result.push(doms[i]);
            }
        }
        return result;
    },
    //层次选择器
    $cengci: function (select) {
        var sel = $$.trim(select).split(" ");
        var context = [];
        var result = [];
        for (var i = 0, len = sel.length; i < len; i++) {
            //这一步非常重要
            result = [];//这里一定要制空result
            var item = sel[i];//#container .div
            item = $$.trim(item);//去除前后的空格
            var first = item.charAt(0);// 第一个字符  # .
            var index = item.indexOf(first);
            var name = item.slice(1);//选择器的名字
            if (first === "#") {
                //这里一般默认id选择器写在第一个,后面不再写id选择器,一般也是这么用的
                pushArray([$$.$id(name)]);
                context = result;
            } else if (first === ".") {
                //之前已经存在选择器了
                if (context.length) {
                    for (var j = 0, contextLen = context.length; j < contextLen; j++) {
                        pushArray($$.$class(name, context[j]));
                    }
                } else {
                    pushArray($$.$class(name));
                }
                context = result;
            } else {
//
                if (context.length) {
                    for (j = 0, contextLen = context.length; j < contextLen; j++) {
                        pushArray($$.$tag(item, context[j]));
                    }
                } else {
                    pushArray($$.$tag(item));
                }
                context = result;
            }

        }

        return result;

        function pushArray(doms) {

            for (var j = 0, domlen = doms.length; j < domlen; j++) {
                result.push(doms[j]);
            }
        }


    },
    //层次加多组
    $select: function (content) {
        content = $$.trim(content);
        //首先应该是分组,然后才是层次
        var result= [];
        var selects = content.split(",");
        for (var i=0,len=selects.length; i<len; i++){
            //selects[i]就是一个层次选择器
            var select = selects[i];
            select = $$.trim(select);
            var context = [];

            context = $$.$cengci(select);
            console.log("context:"+context);
            pushArray(context);

        }
        console.log(result);
        return result;

        function pushArray(doms){
            for(var j= 0, domlen = doms.length; j < domlen; j++){
                result.push(doms[j])
            }
        }
    },
    //h5实现的选择器
    $selectAll:function (selector, context) {
        context = context || document;
        return context.querySelectorAll(selector);
    }

});


$$.extend($$, {
    css:function (ctx, key, value) {
        //ctx可能传进来的是选择器或者直接就是dom对象了
        var doms = $$.isString(ctx) ? $$.$selectAll(ctx):ctx;
        ////如果获取的是集合
        if (doms.length) {
            // 如果是设置值
            if (value){
                for(var i=0,len=doms.length; i<len; i++){
                    setStyle(doms[i], value);
                }
                //这是获取值
            }else{
                return getStyle(doms[0]);
            }
        }else{
            //这是获取的是单个
            if (value){
                setStyle(doms);
            }else {
                getStyle(dom);
            }
        }

        //这里的dom就用单个元素就行了
        function getStyle(dom) {
            if (dom.currentStyle){
                //如果是早起的IE
                return dom.currentStyle[key];
            }else {
                return window.getComputedStyle(dom, null)[key];
            }
        }
        function setStyle(dom) {
            dom.style[key] = value;
        }

    },
    //可见宽高
    width:function (id){
        return $$.$id(id).clientWidth;
    },
    height:function (id){
        return $$.$id(id).clientHeight;
    },
    //元素实际宽高
    scrollWidth:function (id){
        return $$.$id(id).scrollWidth;
    },
    scrollHeight:function (id){
        return $$.$id(id).scrollHeight;
    },

    //滚动距离页面顶部和左部的距离
    scrollTop:function (id){
        return $$.$id(id).scrollTop;
    },
    scrollLeft:function (id){
        return $$.$id(id).scrollLeft;
    },
    //屏幕的宽高
    screenHeight:function (){
        return  window.screen.height;
    },
    screenWidth:function (){
        return  window.screen.width;
    },


    //文档的宽高
    wWidth:function (){
        return document.documentElement.clientWidth;
    },
    wHeight:function (){
        return document.documentElement.clientHeight;
    },
    //文档滚动区域的整体的高和宽
    wScrollHeight:function () {
        return document.body.scrollHeight;
    },
    wScrollWidth:function () {
        return document.body.scrollWidth;
    },
    //文档滚动的距离
    wScrollTop:function () {
        return window.pageYOffset|| document.documentElement.scrollTop || document.body.scrollTop;
    },
    wScrollLeft:function () {
        return window.pageXOffset || document.documentElement.scrollLeft || document.body.scrollLeft;

    },
    offset:function (id) {
    function offsetLeft(dom) {
        return dom.offsetLeft;
    }
    function offsetTop(dom) {
        return dom.offsetTop;
    }
    var dom = $$.$id(id);
    return {top:offsetTop(dom),left:offsetLeft(dom)};
    },
    absoluteOffset:function(id) {
    function absoluteOffsetLeft(id) {
        var dom = $$.$id(id);
        var left = $$.offset(id).left;
        var parent = dom.offsetParent;
        while (parent != null){
            left += parent.offsetLeft;
            parent = parent.offsetParent;
        }
        return left;
    }
    function absoluteOffsetTop(id) {
        var dom = $$.$id(id);
        var top = $$.offset(id).top;
        var parent = dom.offsetParent;
        while (parent != null){
            top += parent.offsetTop;
            parent = parent.offsetParent;
        }
        return top;
    }

    return {left:absoluteOffsetLeft(id), top:absoluteOffsetTop(id)};
}



});
